# We just have to run the python notebook called toy.ipynb
### Everything is in there